# -*- coding: utf-8 -*-
"""
Crystal Neural Network(crysnet)
Labelled Graph Networks for machine learning of crystal
Created on Tue Oct 12 20:27:50 2021

@author: huzongxiang
"""
__version__ = "0.1.6"