# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 15:15:31 2021

@author: huzongxiang
"""

from .gnnframe import Pretrainer, GNN
from .distframe import Pretrainer_dist