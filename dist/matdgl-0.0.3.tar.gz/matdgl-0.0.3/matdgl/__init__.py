# -*- coding: utf-8 -*-
"""
Material Deep Graph Learning(MatDGL)
Graph Neural Networks for machine learning of materials
Created on Tue Oct 12 20:27:50 2021

@author: huzongxiang
"""
__version__ = "0.0.3"